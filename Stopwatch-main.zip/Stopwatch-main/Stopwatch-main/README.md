# Stopwatch

Coding Ninjas Skill Test

Stopwatch maintains a simple stopwatch functionality. 

Features:

<i><b>Start Button:</b> On click of start button, start the timer If timer is 0 start from beginning else start from wherever last stopped</i>

<i><b>Stop Button:</b> Stop timer once clicked on the stop button</i>

  <i><b>Reset Button:</b> On click of reset stop the watch (if already started) and set timer as 0</i>
